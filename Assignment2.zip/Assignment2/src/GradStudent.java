//Hannah Vu (u3150724)
//Assignment 2 
//Date: August 26th, 2016

public class GradStudent extends Student {
	
	private String preDegree;
	private String yearofGrad;
	
	//Default constructor
	public GradStudent()
	{
		super();
		this.preDegree = null;
		this.yearofGrad = null;
	}
	
	//Parameterized constructor
	public GradStudent (String name, String ID, String address, String phone,
					String subjectNo, String preDegree, String yearofGrad,
					int mark1, int mark2, int mark3)
	{
		super(name, ID, address, phone, subjectNo, mark1, mark2, mark3);
		this.preDegree = preDegree;
		this.yearofGrad = yearofGrad;
	}
	
	//Get method
	public String getPreDegree()
	{
		return this.preDegree;
	}
	
	public String getYearofGrad()
	{
		return this.yearofGrad;
	}
	
	//Set method
	public String setPreDegree(String preDegree)
	{
		return this.preDegree = preDegree;
	}
	
	public String setYearofGrad (String yearofGrad)
	{
		return this.yearofGrad = yearofGrad;
	}
	
	//String method
	public String toString()
	{
		return "GRADUATE STUDENT: \n" + super.toString() + "Previous degree: " 
				+ this.preDegree + "\n" + "Year of Graduation: " + this.yearofGrad
				+ "\n" + "Grade: " + this.calGrade();
	}
	
	//Calculate the grade
	public String calGrade() 
	{
		String grade = " ";
		double total = mark1+mark2+mark3;
		double total1 = mark2+mark3;
		
		if (total>15 || total1>18)
		{
			grade = "Pass";
		}
		else
		{
			grade = "Fail";
		}
		
		return grade;
	}

}
