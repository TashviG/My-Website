//Hannah Vu (u3150724)
//Assignment 2 
//Date: August 26th, 2016

public class UGStudent extends Student {
	
	//Default constructor
	public UGStudent()
	{
		super();
	}
	
	//Parameterized constructor
	public UGStudent(String name, String ID, String address, String phone,
			String subjectNo, int mark1, int mark2, int mark3)
	{
		super(name, ID, address, phone, subjectNo, mark1, mark2, mark3);
	}
	
	//String method
	public String toString()
	{
		return "UNDERGRADUATE STUDENT" + "\n" + super.toString() 
				+ "Grade: " + this.calGrade();
	}
	
	//Calculate the grade
	public String calGrade()
	{
		String grade = " ";
		double total = mark1+mark2+mark3;
		
		if (total>15)
		{
			grade = "Pass";
		}
		else 
		{
			grade = "Fail";
		}
		return grade;
	}
}
