//Hannah Vu (u3150724)
//Assignment 2 
//Date: August 26th, 2016

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileIO {
	
	final int STUDENT_SIZE = 100;		//the number of student
	private Student [] Student_list = new Student[STUDENT_SIZE];		//array of student list
	int student_Count = 0;
	
	//Read input file
	public Student[] MyfileReader() throws IOException
	{
		BufferedReader inFile = new BufferedReader((new FileReader("Student.txt")));	//open file
        String line = inFile.readLine();		//read the first line
        
        while(line != null)			//check whether line is null 
        {
        	System.out.println(line);
            String [] str = line.split(";");	//split all element by ";"
           
            //check if length of line by each element is 8, so it is undergraduate students
            if (str.length == 8)
            {
            	Student_list[student_Count] = new UGStudent(str[0], str[1], str[2], str[3], str[4],
            			Integer.parseInt(str[5]), Integer.parseInt(str[6]), Integer.parseInt(str[7]));
            }
            
            //otherwise, it is graduate students
            else
            {
            	Student_list[student_Count] = new GradStudent(str[0], str[1], str[2], str[3], str[4],
            			str[5], str[6], Integer.parseInt(str[7]), Integer.parseInt(str[8]),
            			Integer.parseInt(str[9]));
            }
            
            student_Count++;
            line = inFile.readLine();
           
        }
        
        //close the file
        inFile.close();
    
        return Student_list;
	}
	
	public int Student_c()
	{
		return student_Count;
	}
}
