//Hannah Vu (u3150724)
//Assignment 2 
//Date: August 26th, 2016

public abstract class Student {
	
	protected String name; 
	protected String ID;
	protected String address;
	protected String phone;
	protected String subjectNo;
	protected int mark1, mark2, mark3;
	
	//Default constructor
	public Student()
	{
		this.name = null;
		this.ID = null;
		this.address = null;
		this.phone = null;
		this.subjectNo = null;
		this.mark1 = 0;
		this.mark2 = 0;
		this.mark3 = 0;
	}
	
	//Parameterized constructor
	public Student(String name, String ID, String address, String phone,
					String subjectNo, int mark1, int mark2, int mark3)
	{
		this.name = name;
		this.ID = ID;
		this.address = address;
		this.phone = phone;
		this.subjectNo = subjectNo;
		this.mark1 = mark1;
		this.mark2 = mark2;
		this.mark3 = mark3;
	}
	
	//Get method
	public String getName()
	{
		return this.name;
	}
	
	public String getID()
	{
		return this.ID;
	}
	
	public String getAddress()
	{
		return this.address;
	}
	
	public String getPhone()
	{
		return this.phone;
	}
	
	public String getSubjectNo()
	{
		return this.subjectNo;
	}
	
	public int getMark1()
	{
		return this.mark1;
	}
	
	public int getMark2()
	{
		return this.mark2;
	}
	
	public int getMark3()
	{
		return this.mark3;
	}
	
	//Set method
	public String setName(String name)
	{
		return this.name = name;
	}
	
	public String setID(String ID)
	{
		return this.ID = ID;
	}
	
	public String setPhone(String phone)
	{
		return this.phone = phone;
	}
	
	public String setAddress(String address)
	{
		return this.address = address;
	}
	
	public String setSubjectNo(String subjectNo)
	{
		return this.subjectNo = subjectNo;
	}
	
	public int setMark1(int mark1)
	{
		return this.mark1 = mark1;
	}
	
	public int setMark2(int mark2)
	{
		return this.mark2 = mark2;
	}
	
	public int setMark3(int mark3)
	{
		return this.mark3 = mark3;
	}
	
	//String method
	public String toString()
	{
		String student;
		student = "Name: " + name + "\n" + "ID: " + ID + "\n" 
					+ "Address:  " + address + "\n" + "Phone: " 
					+ phone + "\n" + "Subject Number: " +  subjectNo 
					+ "\n" + "Mark 1: " + mark1 + "\n" + "Mark 2: " + mark2 
					+ "\n" + "Mark 3: " + mark3 + "\n";
		return student;
	}
	
	//abstract method
	public abstract String calGrade();
	
}
