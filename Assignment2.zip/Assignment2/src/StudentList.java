//Hannah Vu (u3150724)
//Assignment 2 
//Date: August 26th, 2016

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class StudentList {
	
	private static final String StudentFileReader = null;
	private FileIO stuf;
	private Student[] student;
	public String[] stuID;
	public String[] stuDetails;
	
	public List udStudent = new ArrayList();
	public List grStudent = new ArrayList();
	
	private int studentCount;
	
	public StudentList() throws IOException
	{
		stuf = new FileIO();
		student = stuf.MyfileReader();
		studentCount = stuf.Student_c();
	}
	
	//get students' details
	public String[] StudentDetails()
	{
		stuDetails = new String[studentCount];
		
		//distinguish between Graduate and Undergraduate Student
		for (int i=0; i<student.length; i++)
		{
			if (student[i] instanceof UGStudent)
			{
				stuDetails[i] = ((UGStudent)student[i]).toString();
			}
			
			else if (student[i] instanceof GradStudent)
			{
				stuDetails[i] = ((GradStudent)student[i]).toString();
			}
		}
		
		return stuDetails;
	}
	
	//Create the list to save Undergraduate student
	public List udStudent()
	{
		for (int i=0; i<student.length; i++)
		{
			if(student[i] instanceof UGStudent)
			{
				udStudent.add(student[i]);
			}
		}
		
		return udStudent;
	}
	
	//Create the list to save Graduate student
	public List grStudent()
	{
		for (int i=0; i<student.length; i++)
		{ 
			if (student[i] instanceof GradStudent)
			{
				grStudent.add(student[i]);
			}
		}
		
		return grStudent;
	}
	
	//get ID from Graduate and Undergraduate Student 
	public String[] getID()
	{
		stuID =  new String[studentCount];
		
		//Divide all students into Graduate and Undergraduate ones to get separate IDs
		for (int i=0; i<studentCount; i++)
		{
			if (student[i] instanceof UGStudent)
			{
				stuID[i] = ((UGStudent)student[i]).getID();
			}
			
			else if (student[i] instanceof GradStudent)
			{
				stuID[i] = ((GradStudent)student[i]).getID();
			}
		}
		
		return stuID;
	}
	
}
