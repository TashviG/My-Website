import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import java.io.IOException;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JToolBar;
import javax.swing.JDesktopPane;
import javax.swing.event.AncestorListener;
import javax.swing.event.AncestorEvent;

public class StudentForm {

	private JFrame frame;
	private JTextPane txtp_info;
	private JComboBox cmbID;
	
	String[] stuDetails;
	static StudentList stulist = null;
	private JTextField textField_ID;
	private JTextField textField_name;
	private JTextField textField_address;
	private JTextField textField_phone;
	private JTextField textField_subjectNo;
	private JTextField textField_mark1;
	private JTextField textField_mark2;
	private JTextField textField_mark3;
	private JTextField textField_preDegree;
	private JTextField textField_yearOfgrad;
	private JCheckBox chckbxGrad;
	private JLabel lblName;
	private JLabel lblYearOfGraduation;
	private JLabel lblPredegree;
	private JLabel lblId;
	private JLabel lblAddress;
	private JLabel lblMark1; 
	private JLabel lblMark_2;
	private JLabel lblMark_3;
	private JLabel lblSubjectNumber;
	private JLabel lblPhone;
	
	/**
	 * Launch the application.
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException{
		
		stulist = new StudentList();
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentForm window = new StudentForm();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StudentForm() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		//Students' details
		stuDetails = stulist.StudentDetails();
		String[] stuID = stulist.getID();
		
		List udStudent = stulist.udStudent();
		List grStudent = stulist.grStudent();
		
		frame = new JFrame();
		frame.setBounds(100, 100, 863, 657);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		//Name of the form
		JLabel lblStudentForm = new JLabel("STUDENT FORM");
		lblStudentForm.setForeground(new Color(139, 0, 0));
		lblStudentForm.setHorizontalAlignment(SwingConstants.CENTER);
		lblStudentForm.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblStudentForm.setBounds(220, 11, 426, 36);
		frame.getContentPane().add(lblStudentForm);
		
		//Get ID from student list to display 
		cmbID = new JComboBox();
		cmbID.setFont(new Font("Tahoma", Font.BOLD, 11));
		cmbID.setForeground(new Color(139, 0, 0));
		cmbID.setBackground(new Color(255, 255, 255));
		cmbID.setModel(new DefaultComboBoxModel(stuID));
		cmbID.setToolTipText("Choose the ID");
		cmbID.setBounds(53, 82, 178, 36);
		frame.getContentPane().add(cmbID);
		
		//Click this button the information will appear in text pane
		JButton btnDisplay = new JButton("Display");
		btnDisplay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println(cmbID.getSelectedItem());
				
				if (cmbID.getSelectedItem().equals(stuID[0]))
				{
					txtp_info.setText(stuDetails[0]);
				}
				
				else if (cmbID.getSelectedItem().equals(stuID[1]))
				{
					txtp_info.setText(stuDetails[1]);
				}
				
				else if (cmbID.getSelectedItem().equals(stuID[2]))
				{
					txtp_info.setText(stuDetails[2]);
				}
				
				if (cmbID.getSelectedItem().equals(stuID[3]))
				{
					txtp_info.setText(stuDetails[3]);
				}
					
				else if (cmbID.getSelectedItem().equals("All Undergraduate Student"))
				{
				JOptionPane.showMessageDialog(null, udStudent.toString());
				}
					
				if (cmbID.getSelectedItem().equals("All Graduate Student"))
				{
					JOptionPane.showMessageDialog(null, grStudent.toString());
				}
			}
		});	
		btnDisplay.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnDisplay.setBounds(76, 172, 128, 36);
		frame.getContentPane().add(btnDisplay);
		
		//Click button "Quit" to exit the form
		JButton btn_Quit = new JButton("Quit");
		btn_Quit.setForeground(new Color(139, 0, 0));
		btn_Quit.setFont(new Font("Tahoma", Font.BOLD, 16));
		btn_Quit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btn_Quit.setBounds(656, 529, 118, 36);
		frame.getContentPane().add(btn_Quit);
		
		//The information will be appeared in this area
		txtp_info = new JTextPane();
		txtp_info.setForeground(Color.WHITE);
		txtp_info.setBackground(Color.BLACK);
		txtp_info.setBounds(306, 82, 277, 529);
		frame.getContentPane().add(txtp_info);
		
		//List all Undergraduate Students
		JButton btnUD = new JButton("All Undergraduate Student");
		btnUD.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnUD.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtp_info.setText(udStudent.toString());
			}
		});
		btnUD.setBounds(42, 317, 197, 51);
		frame.getContentPane().add(btnUD);
		
		//List all Graduate Students
		JButton btnGR = new JButton("All Graduate Student");
		btnGR.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnGR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtp_info.setText(grStudent.toString());
			}
		});
		btnGR.setBounds(42, 240, 197, 51);
		frame.getContentPane().add(btnGR);
		
		//List all Graduate Students with Pass Grade
		JButton btnAllGraduateStudent = new JButton("All Graduate Student with Pass Grade");
		btnAllGraduateStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (((GradStudent) grStudent).calGrade() == "Pass")
				{
					txtp_info.setText(grStudent.toString());
				}
			}
		});
		btnAllGraduateStudent.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnAllGraduateStudent.setBounds(10, 412, 286, 51);
		frame.getContentPane().add(btnAllGraduateStudent);
		
		//List all Undergraduate Students with Pass Grade
		JButton btnAllUndergraduateStudent = new JButton("All Undergraduate Student with Pass Grade");
		btnAllUndergraduateStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (((UGStudent) udStudent).calGrade() == "Pass")
				{
					txtp_info.setText(udStudent.toString());
				}
			}
		});
		btnAllUndergraduateStudent.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnAllUndergraduateStudent.setBounds(10, 474, 286, 51);
		frame.getContentPane().add(btnAllUndergraduateStudent);
		
		//Click this button to get information from textfields input by users and save it into list 
		JButton btnAddNewStudent = new JButton("Add new student");
		btnAddNewStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnAddNewStudent.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnAddNewStudent.setBounds(636, 457, 163, 31);
		frame.getContentPane().add(btnAddNewStudent);
		
		//Type ID information to add a new student
		textField_ID = new JTextField();
		textField_ID.setBounds(726, 164, 86, 20);
		frame.getContentPane().add(textField_ID);
		textField_ID.setColumns(10);
		
		//Type name information to add a new student
		textField_name = new JTextField();
		textField_name.setColumns(10);
		textField_name.setBounds(726, 133, 86, 20);
		frame.getContentPane().add(textField_name);
		
		//Click this checkbox if a new student is graduated
		chckbxGrad = new JCheckBox("Graduate Student");
		chckbxGrad.setFont(new Font("Tahoma", Font.BOLD, 11));
		chckbxGrad.setBounds(615, 82, 146, 23);
		frame.getContentPane().add(chckbxGrad);
		
		//Click this checkbox if the new student is undergraduate one
		JCheckBox chckbxUndergraduateStudent = new JCheckBox("Undergraduate Student");
		chckbxUndergraduateStudent.setFont(new Font("Tahoma", Font.BOLD, 11));
		chckbxUndergraduateStudent.setBounds(615, 103, 197, 23);
		frame.getContentPane().add(chckbxUndergraduateStudent);
		
		//Type address information to add a new student
		textField_address = new JTextField();
		textField_address.setColumns(10);
		textField_address.setBounds(726, 193, 86, 20);
		frame.getContentPane().add(textField_address);
		
		//Type phone information to add a new student
		textField_phone = new JTextField();
		textField_phone.setColumns(10);
		textField_phone.setBounds(726, 224, 86, 20);
		frame.getContentPane().add(textField_phone);
		
		//Type subject number information to add a new student
		textField_subjectNo = new JTextField();
		textField_subjectNo.setColumns(10);
		textField_subjectNo.setBounds(726, 255, 86, 20);
		frame.getContentPane().add(textField_subjectNo);
		
		//Type the first mark information to add a new student
		textField_mark1 = new JTextField();
		textField_mark1.setColumns(10);
		textField_mark1.setBounds(726, 287, 86, 20);
		frame.getContentPane().add(textField_mark1);
		
		//Type the second mark information to add a new student
		textField_mark2 = new JTextField();
		textField_mark2.setColumns(10);
		textField_mark2.setBounds(726, 317, 86, 20);
		frame.getContentPane().add(textField_mark2);
		
		//Type the third mark information to add a new student
		textField_mark3 = new JTextField();
		textField_mark3.setColumns(10);
		textField_mark3.setBounds(726, 348, 86, 20);
		frame.getContentPane().add(textField_mark3);
		
		//Type predegree information to add a new graduate student
		textField_preDegree = new JTextField();
		textField_preDegree.setColumns(10);
		textField_preDegree.setBounds(726, 379, 86, 20);
		frame.getContentPane().add(textField_preDegree);
		
		//Type year of graduation information to add a new graduate student
		textField_yearOfgrad = new JTextField();
		textField_yearOfgrad.setColumns(10);
		textField_yearOfgrad.setBounds(726, 410, 86, 20);
		frame.getContentPane().add(textField_yearOfgrad);
		
		lblName = new JLabel("Name:");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblName.setForeground(new Color(139, 0, 0));
		lblName.setBounds(615, 133, 67, 20);
		frame.getContentPane().add(lblName);
		
		lblId = new JLabel("ID:");
		lblId.setForeground(new Color(139, 0, 0));
		lblId.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblId.setBounds(615, 164, 67, 20);
		frame.getContentPane().add(lblId);
		
		lblAddress = new JLabel("Address:");
		lblAddress.setForeground(new Color(139, 0, 0));
		lblAddress.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblAddress.setBounds(615, 193, 67, 20);
		frame.getContentPane().add(lblAddress);
		
		lblPhone = new JLabel("Phone:");
		lblPhone.setForeground(new Color(139, 0, 0));
		lblPhone.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPhone.setBounds(615, 225, 67, 20);
		frame.getContentPane().add(lblPhone);
		
		lblSubjectNumber = new JLabel("Subject Number:");
		lblSubjectNumber.setForeground(new Color(139, 0, 0));
		lblSubjectNumber.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblSubjectNumber.setBounds(615, 255, 103, 20);
		frame.getContentPane().add(lblSubjectNumber);
		
		lblMark1 = new JLabel("Mark 1:");
		lblMark1.setForeground(new Color(139, 0, 0));
		lblMark1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblMark1.setBounds(615, 288, 67, 20);
		frame.getContentPane().add(lblMark1);
		
		lblMark_2 = new JLabel("Mark 2:");
		lblMark_2.setForeground(new Color(139, 0, 0));
		lblMark_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblMark_2.setBounds(615, 320, 67, 20);
		frame.getContentPane().add(lblMark_2);
		
		lblMark_3 = new JLabel("Mark 3:");
		lblMark_3.setForeground(new Color(139, 0, 0));
		lblMark_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblMark_3.setBounds(615, 349, 67, 20);
		frame.getContentPane().add(lblMark_3);
		
		lblPredegree = new JLabel("Predegree:");
		lblPredegree.setForeground(new Color(139, 0, 0));
		lblPredegree.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPredegree.setBounds(615, 382, 67, 20);
		frame.getContentPane().add(lblPredegree);
		
		lblYearOfGraduation = new JLabel("Year of graduation:");
		lblYearOfGraduation.setForeground(new Color(139, 0, 0));
		lblYearOfGraduation.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblYearOfGraduation.setBounds(615, 412, 118, 20);
		frame.getContentPane().add(lblYearOfGraduation);
	}
}
